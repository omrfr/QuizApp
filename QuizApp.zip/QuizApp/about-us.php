<?php 
    echo("Biz üç kişiyiz Ömer Berkay Hasan");
?>