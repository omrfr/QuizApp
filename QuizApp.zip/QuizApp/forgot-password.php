<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <style>
        h1{
            text-align: center;
            font-family: Verdana;
            font-size:2em;
            font-weight:bold;
        }
    </style>
    <h1>Yea I forgot it!</h1>
</body>
</html>